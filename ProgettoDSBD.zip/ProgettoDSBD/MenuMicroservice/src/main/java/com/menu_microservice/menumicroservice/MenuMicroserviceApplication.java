package com.menu_microservice.menumicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenuMicroserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MenuMicroserviceApplication.class, args);
    }

}
