package com.ordini_microservice.ordinimicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdiniMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
