package com.ordini_microservice.ordinimicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdiniMicroserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrdiniMicroserviceApplication.class, args);
    }

}
