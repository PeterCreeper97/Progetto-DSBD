package com.ordini_microservice.ordinimicroservice.Kafka;


import com.google.gson.Gson;
import com.ordini_microservice.ordinimicroservice.DataModel.OrderCreate;
import com.ordini_microservice.ordinimicroservice.DataModel.Ordine;
import com.ordini_microservice.ordinimicroservice.Repository.OrdineRepository;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumer {

    @Autowired
    OrdineRepository repository;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @KafkaListener(topics = "${KAFKA_TOPIC_ORDERS}", groupId = "${KAFKA_GROUP_ID}")
    public void listenOrderValidation(ConsumerRecord<String, String> record) {
        if(record != null){

            if(record.key().equals("order_confirmed")) {

                OrderCreate ordine = new Gson().fromJson(record.value(), OrderCreate.class);

                Ordine order_confirmed = new Ordine();

                order_confirmed.set_id(ordine.getOrder_id());
                order_confirmed.setPietanze(ordine.getPietanze());
                order_confirmed.setStato("order_confirmed");

                System.out.println("KAFKA LISTENER ORDINI: " + ordine.toString());

                Ordine prova = repository.save(order_confirmed);

                System.out.println("KAFKA LISTENER ORDINI DOPO SAVE: " + prova.toString());

            }else{

                OrderCreate ordine = new Gson().fromJson(record.value(), OrderCreate.class);

                Ordine order_failed = new Ordine();

                order_failed.set_id(ordine.getOrder_id());
                order_failed.setPietanze(ordine.getPietanze());
                order_failed.setStato("order_failed");

                System.out.println("KAFKA LISTENER ORDINI: " + ordine.toString());

                Ordine prova = repository.save(order_failed);

                System.out.println("KAFKA LISTENER ORDINI DOPO SAVE: " + prova.toString());

            }
        /*if(record != null){
            if(record.key().equals("order_validation")) {
                System.out.println("Messaggio ricevuto sul topic orders con chiave order_validation");
                OrderValidation orderValidation = new Gson().fromJson(record.value(), OrderValidation.class);
                if (orderValidation.getStatus() != 0) {
                    System.out.println("Lo stato relativo al messaggio è diverso da 0");
                    TotalOrder order = repository.findBy_id(new ObjectId(orderValidation.getOrderId()));
                    order.setStatus("Abort");
                    repository.save(order);
                }
            }else if(record.key().equals("order_paid")){
                System.out.println("Messaggio ricevuto sul topic orders con chiave order_paid");
                OrderPaid orderPaid = new Gson().fromJson(record.value(), OrderPaid.class);
                TotalOrder order = repository.findTotalOrderBy_idAndUserIdAndAmount(new ObjectId(orderPaid.getOrderId()),
                        orderPaid.getUserId(), orderPaid.getAmount());
                if(order != null){
                    System.out.println("L'ordine ricevuto ha tutti i parametri corretti.");
                    order.setStatus("Paid");
                    repository.save(order);
                    kafkaTemplate.send(kafkaTopicNotification, "order_paid", new Gson().toJson(orderPaid));
                    kafkaTemplate.send(kafkaTopicInvoicing, "order_paid", new Gson().toJson(orderPaid));
                    System.out.println("Viene inviato un messaggio sui topic notification e invoicing con chiave order_paid");
                }else{
                    System.out.println("L'ordine ha dei parametri non corrispondenti.");
                    TotalOrder order_error = repository.findTotalOrderBy_idAndUserId(new ObjectId(orderPaid.getOrderId()),
                            orderPaid.getUserId());
                    if(order_error != null){
                        //esiste un ordine ma c'è l'amount sbagliato.
                        order_error.setStatus("Abort");
                        repository.save(order_error);
                        orderPaid.getExtraArgs().put("error", "WRONG_AMOUNT_PAID");
                    }else{
                        orderPaid.getExtraArgs().put("error", "ORDER_NOT_FOUND");
                    }
                    kafkaTemplate.send(kafkaTopicLogging, "order_paid_validation_failure", new Gson().toJson(orderPaid));
                    System.out.println("Viene inviato un messaggio sul topic logging con chiave order_paid_validation_failure");
                }
            }*/

        }

    }

}
