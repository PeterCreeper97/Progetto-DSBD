package com.pietanze_microservice.pietanzemicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PietanzeMicroserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PietanzeMicroserviceApplication.class, args);
    }

}
