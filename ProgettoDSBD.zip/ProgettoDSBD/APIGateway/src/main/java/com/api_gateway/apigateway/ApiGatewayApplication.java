package com.api_gateway.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;

import java.net.InetAddress;
import java.net.UnknownHostException;

@SpringBootApplication
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }

    @Bean
    public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) throws UnknownHostException {

        //System.out.print(InetAddress.getByName("pietanzemicroservice:8080").getHostAddress());

        return builder.routes()
                .route("pietanze_modulo", r -> r.path("/pietanze/**")
                        .uri("pietanzemicroservice:8080"))
                .build();


    }

}
